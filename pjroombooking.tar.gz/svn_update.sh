#### Updates repository and sets permissions accordingly.

svn update /var/www/pjroombooking/
sudo chown --recursive www-data:www-data /var/www/pjroombooking/